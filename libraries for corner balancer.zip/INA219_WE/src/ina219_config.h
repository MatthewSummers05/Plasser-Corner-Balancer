#ifndef INA219_CONFIG_H_
#define INA219_CONFIG_H_
/* Uncomment the following line to use TinyWireM instead of Wire */
//#define USE_TINY_WIRE_M_
#endif