
#ifndef COMPAT_TASKMGR_H
#define COMPAT_TASKMGR_H

#include <TaskManagerIO.h>

#endif //COMPAT_TASKMGR_H
